package com.wangdazhi.wangaiagent.demo.invoke;

public interface TestApiKey {
    String API_KEY="sk-bc00d696cc5947c6bdcf4554fb58755b";
}
