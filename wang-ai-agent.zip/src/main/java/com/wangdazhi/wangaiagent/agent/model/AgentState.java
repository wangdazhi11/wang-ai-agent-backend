package com.wangdazhi.wangaiagent.agent.model;

public enum AgentState {
    // 空闲、运行中、完成、错误
    IDLE,
    RUNNING,
    FINISHED,
    ERROR
}
